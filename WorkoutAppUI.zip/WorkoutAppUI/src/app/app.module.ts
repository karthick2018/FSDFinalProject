import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ChartsModule } from 'ng2-charts';
import { AngularDateTimePickerModule } from 'angular2-datetimepicker';
import { MyDatePickerModule } from 'mydatepicker';
import { AppComponent } from './app.component';
import { WorkoutComponent } from './components/workout/workout.component';
import { ViewAllWorkoutComponent } from './components/view-all-workout/view-all-workout.component';
import { TrackWorkoutComponent } from './components/track-workout/track-workout.component';
import { StartEndWorkComponent } from './components/start-end-work/start-end-work.component';
import { CategoryComponent } from './components/category/category.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { CategoryPipe } from './components/pipe/category.pipe';
import { WorkoutPipe } from './components/pipe/workout.pipe';
import { AmazingTimePickerModule } from 'amazing-time-picker'; // this line you need
const appRoutes: Routes = [
  { path: 'ViewAllWorkout', component: ViewAllWorkoutComponent },
  { path: 'StartWorkout/:page/:id', component: StartEndWorkComponent,data: { page: 'StartWorkout' }},
  { path: 'EndWorkout/:page/:id', component: StartEndWorkComponent,data: { page: 'EndWorkout' } },
  { path: 'EditWorkout/:id',component: WorkoutComponent,data: { page: 'EditWorkout' } },
  { path: 'AddWorkout', component: WorkoutComponent,data: { page: 'AddWorkout' } },  
  { path: 'Category', component: CategoryComponent },
  { path: 'Track', component: TrackWorkoutComponent },
  { path: '', redirectTo: '/ViewAllWorkout', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    WorkoutComponent,
    ViewAllWorkoutComponent,
    TrackWorkoutComponent,
    StartEndWorkComponent,
    CategoryComponent,
    PageNotFoundComponent,
    CategoryPipe,
    WorkoutPipe
  ],
  imports: [
    BrowserModule,AmazingTimePickerModule,ChartsModule,MyDatePickerModule,
    HttpClientModule, AngularDateTimePickerModule,
	RouterModule.forRoot(appRoutes,{ enableTracing: true })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
