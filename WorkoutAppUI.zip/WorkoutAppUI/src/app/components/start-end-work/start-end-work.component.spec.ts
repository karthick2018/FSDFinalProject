import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StartEndWorkComponent } from './start-end-work.component';

describe('StartEndWorkComponent', () => {
  let component: StartEndWorkComponent;
  let fixture: ComponentFixture<StartEndWorkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StartEndWorkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StartEndWorkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
