import { Component } from '@angular/core';
import { Directive, OnInit, OnDestroy, Input } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {Category} from '../model/Category';
import {Workout} from '../model/Workout';
import {WorkoutActive} from '../model/WorkoutActive';
import { WorkoutService } from '../service/workout.service';
import {IMyDpOptions} from 'mydatepicker';
import { AmazingTimePickerService } from 'amazing-time-picker';

@Component({
  selector: 'app-start-end-work',
  templateUrl:'./start-end-work.component.html',
  providers: [WorkoutService],
  styleUrls: ['./start-end-work.component.css']
})
export class StartEndWorkComponent implements OnInit{	
	page:string;
	workout=new Workout();
	workoutId:string;
	workoutActive=new WorkoutActive();
	activeworkout:Workout=new Workout();
	currentDateTime = new Date();
	startEndTime=new Date();
	
	constructor(private atp: AmazingTimePickerService,private workoutService: WorkoutService,private router: Router,private route: ActivatedRoute) {
		this.route.params.subscribe( params => console.log(params));
		
	}	
	public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy'
    };
	
    settings = {
        bigBanner: true,
        timePicker: true,
        format: 'hh:mm a',
        defaultOpen: false
    }	

    public workoutDate: any = { date: { year: this.currentDateTime.getFullYear(), month: this.currentDateTime.getMonth(), day: this.currentDateTime.getDay()+1 } };	
	
	ngOnInit() {
		this.page = this.route.snapshot.paramMap.get('page');	
		this.workoutId = this.route.snapshot.paramMap.get('id');
		this.getWorkout(this.workoutId);					
		console.log(this.page+" Workout Page.......");
	}
	
	/** GET getWorkout by id. Will 404 if id not found */
	getWorkout(id: string){	
	  this.workoutService.getWorkout(id)
      .subscribe(workout => this.workout = workout);	  
	}	
  
	cancelWorkoutActive() {
        this.router.navigate(['/ViewAllWorkout']);
    }	
	startEndWorkoutActive(){		
		if(this.workoutDate!=null && this.startEndTime!=null){
			var selectedDateTime:Date = new Date(this.workoutDate.date.day+"/"+
			this.workoutDate.date.month+"/"+this.workoutDate.date.year);			
			if(this.page=="Start"){
				this.workoutActive.startDateTm=selectedDateTime;
				this.workoutActive.startTm=this.startEndTime;				
			}
			else{
				this.workoutActive.endDateTm=selectedDateTime;	
				this.workoutActive.startTm=this.startEndTime;
			}			
			if(this.workoutActive!=null){				
				this.activeworkout._id=this.workoutId;					
				this.workoutActive.workout=this.activeworkout;				
				this.workoutService.saveWorkoutActive(this.workoutActive)
				.subscribe(workoutActive => {console.log("workoutActive Saved");
				  this.router.navigate(['/ViewAllWorkout']);				  
				});				
			}
		}	
	}
	
	openTimer() {
		const amazingTimePicker = this.atp.open();
		amazingTimePicker.afterClose().subscribe(time => {
		  console.log("time..................."+time);
		});
    }
}