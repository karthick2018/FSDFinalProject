export class Category {	
	constructor() {}
	
	_id:string;    
	categoryName:string;
}