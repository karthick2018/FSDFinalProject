import {Workout} from './Workout';

export class WorkoutActive {
  workoutComments:string;  
  startDateTime: string;  
  endDateTime: string;
  startDateTm: Date;
  endDateTm: Date;
  startTm:Date;
  endTm:Date;
  workout:Workout;
}