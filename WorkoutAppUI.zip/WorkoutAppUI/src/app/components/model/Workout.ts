
import {Category} from './Category';

export class Workout {
  /*constructor(public id: string,  public workoutTit: string, public notes:string,public calBurnt:number, public catid:string) { 
		this._id=id;
		this.workoutTitle=workoutTit;
		this.workoutNotes=notes;
		this.caloriesBurntPerMin=calBurnt;		
  }*/
  _id:string;  
  workoutTitle:string;
  workoutNotes:string;
  caloriesBurntPerMin:number;
  category:Category;
  workoutId:string;
}