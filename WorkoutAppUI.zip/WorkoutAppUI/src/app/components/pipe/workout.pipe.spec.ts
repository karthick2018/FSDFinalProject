import { WorkoutPipe } from './workout.pipe';

describe('WorkoutPipe', () => {
  it('create an instance', () => {
    const pipe = new WorkoutPipe();
    expect(pipe).toBeTruthy();
  });
});
