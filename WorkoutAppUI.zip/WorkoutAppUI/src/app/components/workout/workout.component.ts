import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Directive, OnDestroy, Input } from '@angular/core';

import {Category} from '../model/Category';
import {Workout} from '../model/Workout';
import {WorkoutActive} from '../model/WorkoutActive';

import { CategoryService } from '../service/category.service';
import { WorkoutService } from '../service/workout.service';

@Component({
  selector: 'app-workout',
  templateUrl: './workout.component.html',  
  providers: [CategoryService,WorkoutService],
  styleUrls: ['./workout.component.css']
})
export class WorkoutComponent  implements OnInit {	
    selectedCategory:Category;
	categories:Category[];
	name:string;
  
	workoutId:string;
	workoutPageType:string;
	workoutPageAction:string;	
	workout=new Workout();
	isEditWorkout:boolean;
	errorMsg:string;
	
	ngOnInit() {
		this.getAllCategories();		
		this.isEditWorkout=false;				
		this.workoutPageType="Create";
		this.workoutPageAction="Add";		
		
		this.workoutId = this.route.snapshot.paramMap.get('id');
		console.log("Id::::::: :"+this.workoutId);
		this.selectedCategory = new Category();		
		
		if(this.workoutId!=null){			
			this.isEditWorkout=true;
			this.workoutPageType="Edit";
			this.workoutPageAction="Update";			
			this.getWorkout(this.workoutId);
						
			if(this.workout.category!=null){
				console.log('--------------->'+this.workout.category.categoryName);
				this.selectedCategory.categoryName=this.workout.category.categoryName;
				this.selectedCategory._id=this.workout.category._id;
			}
		}
		console.log("this.workoutPageType:  "+this.workoutPageType);	
	}	
	
	constructor(private router: Router,private route: ActivatedRoute, private categoryService:CategoryService,private workoutService:WorkoutService) { 
		this.route.params.subscribe(params => console.log(params) );
	}
	  
    //call service to list all available categories
    getAllCategories(): void {
	  this.categoryService.getAllCategories()
      .subscribe(categories => this.categories = categories);
    }
	/** GET getWorkout by id. Will 404 if id not found */
	getWorkout(id: string){	
	  this.workoutService.getWorkout(id)
      .subscribe(workout => this.workout = workout);
	}
	
    //call service to save new Category
    addUpdateWorkout(): void {	  
	    if(this.workoutPageType=="Create"){

	    if(this.workout.workoutTitle==null || this.workout.workoutTitle==''){
			this.errorMsg="Workout Title is mandatory";
			return;
		}	 
		console.log(" this.errorMsg:"+ this.errorMsg);
	    this.errorMsg=null;
		this.workoutService.saveWorkout(this.workout)
			  .subscribe(workout => {				   
				  console.log("Workout Saved");
				  this.router.navigate(['/ViewAllWorkout']);				  
		 });
	  }else{
		  console.log('Update data'+JSON.stringify(this.workout));
		  this.workoutService.updateWorkout(this.workout)
			  .subscribe(workout => {				   
				  console.log("Workout Updated");
				  this.router.navigate(['/ViewAllWorkout']);				  
		 });		  
		 this.router.navigate(['/ViewAllWorkout']);
	  }
  }  
  
  
    aaddUpdateWorkout() {
		console.log("Workout id: "+this.workout._id);
		
        this.router.navigate(['/ViewAllWorkout']);
    }
	cancelWorkoutEdit() {
        this.router.navigate(['/ViewAllWorkout']);
    }
	addCategory() {
        this.router.navigate(['/Category']);
    }
	addCaloriesBurnt(){
		
		if(this.workout.caloriesBurntPerMin!=null && Number(this.workout.caloriesBurntPerMin)>0)
			this.workout.caloriesBurntPerMin=Number(this.workout.caloriesBurntPerMin)+10;
		else
			this.workout.caloriesBurntPerMin=10;
	}
	reduceCaloriesBurnt(){
		if(this.workout.caloriesBurntPerMin!=null && Number(this.workout.caloriesBurntPerMin)>10)
		  this.workout.caloriesBurntPerMin=Number(this.workout.caloriesBurntPerMin)-10;
	    else
		  this.workout.caloriesBurntPerMin=0;
	}
}

