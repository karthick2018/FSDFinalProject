'use strict';
var mongoose = require('mongoose'),

skillsModels = require("../models/SkillsTrackerSchema.js");
var Skills = skillsModels.Skills;
var Associate = skillsModels.Associate;
var AssociateSkills = skillsModels.AssociateSkills;

var Person = skillsModels.Person;
var Story = skillsModels.Story;

var Post = skillsModels.Post;
var User = skillsModels.User;


exports.list_all_skills = function(req, res) {
  Skills.find({}, function(err, skills) {
    if (err)
      res.send(err);
    res.json(skills);
  });
};

exports.create_skills = function(req, res) { 

	var new_skills  = new Skills(req.body); 
	if(typeof req.body.skillName!== 'undefined'){
	  new_skills.skillName=req.body.skillName;
	  new_skills._id= new mongoose.Types.ObjectId();
	  new_skills.save(function(err,skills) {
		if (err)
		  res.send(err);
		res.json(skills);
	  });	  
	}
};

exports.read_a_skills = function(req, res) {
  Skills.findById(req.params._id, function(err, skills) {
    if (err)
      res.send(err);
    res.json(skills);
  });
};

exports.update_a_skills = function(req, res) {    
  Skills.findOneAndUpdate({_id: req.params._id}, req.body, {new: true}, function(err, skills) {
    if (err)
      res.send(err);
    res.json(skills);
  });
};

exports.delete_a_skills = function(req, res) {  
  console.log("delete_a_skills.....>>>>");
  skills.remove({_id:req.params._id}, function(err, skills) {
    if (err)
      res.send(err);
    res.json({ message: 'skills successfully deleted' });
  });
};

//Associate
exports.list_all_associates = function(req, res) {
  Associate.find({}, function(err, associate) {
    if (err)
      res.send(err);
    res.json(associate);
  });
};
exports.create_associate = function(req, res) { 
 
  console.log("req.body:"+JSON.stringify(req.body));
  
   var new_associate  = new Associate();
   if(typeof req.body.associateId!== 'undefined')
		new_associate.associateId=req.body.associateId;
	if(typeof req.body.associateName!== 'undefined')
		new_associate.associateName=req.body.associateName;
	if(typeof req.body.emailAddress!== 'undefined')
		new_associate.emailAddress=req.body.emailAddress;
	if(typeof req.body.mobileNumber!== 'undefined')
		new_associate.mobileNumber=req.body.mobileNumber;
	if(typeof req.body.strength!== 'undefined')
		new_associate.strength=req.body.strength;
	if(typeof req.body.weakness!== 'undefined')
		new_associate.weakness=req.body.weakness;
	if(typeof req.body.remarks!== 'undefined')
		new_associate.remarks=req.body.remarks;
	if(typeof req.body.associateStatus!== 'undefined')
		new_associate.associateStatus=req.body.associateStatus;
	if(typeof req.body.associateLevel!== 'undefined')
		new_associate.associateLevel=req.body.associateLevel;
	if(typeof req.body.picture!== 'undefined')
	  new_associate.picture=req.body.picture;
	if(typeof req.body.associateId!== 'undefined'){
		new_associate._id= new mongoose.Types.ObjectId();
		
	    new_associate.save(function(err, associate) {
	    if(err)
			res.send(err);
		console.log('Associate successfully saved.'+new_associate._id);        
		if(typeof req.body.associateSkillsLst!=='undefined'){
			var associateSkills;
			var associateSkillsLst=[];
			for(var i=0;i<req.body.associateSkillsLst.length;i++){
				associateSkills=new AssociateSkills();
			if(typeof req.body.associateSkillsLst[i].skills!== 'undefined')
			    associateSkills.skills=req.body.associateSkillsLst[i].skills;
			if(typeof req.body.associateSkillsLst[i].skillRating!== 'undefined'){
			  associateSkills.skillRating=req.body.associateSkillsLst[i].skillRating;
			  associateSkills.associate=new_associate._id;
			  associateSkills._id= new mongoose.Types.ObjectId();
			  associateSkills.save(function(err) {
				if (err) throw err;			 
				console.log('AssociateSkills successfully saved.');
				
			  });
			  associateSkillsLst.push(associateSkills);
			}
			}
			new_associate.associateSkillsLst=associateSkillsLst;
		}		
		res.json(new_associate); 
	});
	}
};

exports.read_a_associate = function(req, res) {
  Associate.findById(req.params._id, function(err, associate) {
    if (err)
      res.send(err);
    res.json(associate);
  });
};

exports.update_a_associateq = function(req, res) {    
  Associate.findOneAndUpdate({_id: req.params._id}, req.body, {new: true}, function(err, associate) {
    if (err)
      res.send(err);
    res.json(associate);
  });
};
exports.update_a_associate = function(req, res) { 
  console.log("in update associate....");   
  
  Associate.findOne({_id: req.params._id}, function(err, associate) {
    if (err)
      res.send(err);    
  console.log("associate:;;;;;"+associate);
	 if(typeof req.body.associateId!== 'undefined')
		associate.associateId=req.body.associateId;
	if(typeof req.body.associateName!== 'undefined')
		associate.associateName=req.body.associateName;
	if(typeof req.body.emailAddress!== 'undefined')
		associate.emailAddress=req.body.emailAddress;
	if(typeof req.body.mobileNumber!== 'undefined')
		associate.mobileNumber=req.body.mobileNumber;
	if(typeof req.body.strength!== 'undefined')
		associate.strength=req.body.strength;
	if(typeof req.body.weakness!== 'undefined')
		associate.weakness=req.body.weakness;
	if(typeof req.body.remarks!== 'undefined')
		associate.remarks=req.body.remarks;
	if(typeof req.body.associateStatus!== 'undefined')
		associate.associateStatus=req.body.associateStatus;
	if(typeof req.body.associateLevel!== 'undefined')
		associate.associateLevel=req.body.associateLevel;
	if(typeof req.body.picture!== 'undefined')
	  associate.picture=req.body.picture;
	
	associate.save(function(err){
		if(!err)
			console.log("Updated successfully");
		else
			console.log("Error could not update");
	})
	
	console.log("req.body:"+JSON.stringify(req.body));
	
	if(typeof req.body.associateSkillsLst!=='undefined'){
			var associateSkills;
			var associateSkillsLstUpdtd=[];
			for(var i=0;i<req.body.associateSkillsLst.length;i++){
			
			var asskillID=req.body.associateSkillsLst[i]._id;
			var associateSkillReq=req.body.associateSkillsLst[i];
			console.log("asskillID:"+asskillID);
			AssociateSkills.findOne({_id:asskillID}, function(err, associateSkills) {
				console.log("associateSkills:"+associateSkills);
				if(!associateSkills){
					associateSkills=new AssociateSkills();				
				}
				console.log("associateSkillReq:"+associateSkillReq);
				console.log("req.body:"+JSON.stringify(associateSkillReq));
				if(typeof associateSkillReq.skills!== 'undefined')
					associateSkills.skills=associateSkillReq.skills;
				if(typeof associateSkillReq.skillRating!== 'undefined'){
					associateSkills.skillRating=associateSkillReq.skillRating;
					associateSkills.associate=associate._id;					
					associateSkills.save(function(err) {
						if (err) throw err;			 
							console.log('AssociateSkills successfully saved.');
				    });
				    associateSkillsLstUpdtd.push(associateSkills);
				}				
			});
			}
			associate.associateSkillsLst=associateSkillsLstUpdtd;
	} 
    
    res.json(associate);
  });
};

exports.delete_a_associate = function(req, res) { 
  associate.remove({_id:req.params._id}, function(err, associate) {
    if (err)
      res.send(err);
    res.json({ message: 'Associate successfully deleted' });
  });
};



exports.list_all_person = function(req, res) {
  Person.
  find().
  populate('skills'). 
  exec(function (err, persons) {	  
     if (err)
      res.send(err);  
   res.json(persons);	  
   
  });
};

exports.create_person = function(req, res) {
  var author  = new Person(req.body); 
  if(typeof req.body.name!== 'undefined'){
	author._id= new mongoose.Types.ObjectId();	
  }
  author.save(function (err) {
	 if (err) return res.send(err);
		console.log("author saved successfully:"+author._id);
   });
   res.json(author); 
};

exports.read_a_person = function(req, res) {	
  Person.findOne({_id:req.params._id}).populate('skills')
  .exec(function (err, person) {
    if (err) return res.json(person);    
	res.json(person);  
  });  
};

exports.update_a_person = function(req, res) {    
  Person.findOneAndUpdate({_id: req.params._id}, req.body, {new: true}, function(err, person) {
    if (err)
      res.send(err);
    res.json(person);
  });
};

exports.delete_a_person = function(req, res) {  
  console.log("delete_a_person....");
  person.remove({_id:req.params._id}, function(err, person) {
    if (err)
      res.send(err);
    res.json({ message: 'person successfully deleted' });
  });
};