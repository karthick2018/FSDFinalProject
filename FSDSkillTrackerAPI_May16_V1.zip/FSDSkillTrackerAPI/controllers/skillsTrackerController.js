'use strict';
var mongoose = require('mongoose'),

skillsModels = require("../models/SkillsTrackerSchema.js");
var Skills = skillsModels.Skills;
var Associate = skillsModels.Associate;

exports.list_all_skills = function(req, res) {
  Skills.find({}, function(err, skills) {
    if(err){
	   res.json({ errorMessage: 'Error:List All Skills. Reason: '+err.message });
	}else{
		res.json(skills);
	}
  });
};

exports.create_skills = function(req, res) {
	var new_skills  = new Skills(req.body); 
	if(typeof req.body.skillName!== 'undefined'){
	  new_skills.skillName=req.body.skillName;
	  new_skills._id= new mongoose.Types.ObjectId();
	  new_skills.save(function(err,skills) {
	  if(err){
	    res.json({ errorMessage: 'Error:create skills. Reason: '+err.message });
	  }else{
		res.json(skills);
	  }
	  });	  
	}
};

exports.read_a_skills = function(req, res) {
  Skills.findById(req.params._id, function(err, skills) {
  if(err){
	res.json({errorMessage: 'Error:Reading skills. Reason: '+err.message });
  }else{
	res.json(skills);
  }
  });
};

exports.update_a_skills = function(req, res) {    
  Skills.findOneAndUpdate({_id: req.params._id}, req.body, {new: true}, function(err, skills) {
  if(err){
	res.json({errorMessage: 'Error:Reading skills. Reason: '+err.message });
  }else{
    res.json(skills);
  }
  });
};

exports.delete_a_skills = function(req, res) {  
  console.log("delete_a_skills.....>>>>");
  Skills.remove({_id:req.params._id}, function(err, skills) {
  if(err){
	res.json({errorMessage: 'Error:deleting skills. Reason: '+err.message });
  }
  else{
    res.json({ message: 'skills successfully deleted' });
  }
  });
};

//Associate
exports.list_all_associates = function(req, res) {
 Associate.
  find().
  populate('associateSkills.skill'). 
  exec(function (err, associates) {
    if (err){
		res.json({ errorMessage: 'Error:Could not List all Associates. Reason: '+err.message });
	}else{
		
		res.json(associates);
	}
  });
};
exports.create_associate = function(req, res) {  
  console.log("req.body:"+JSON.stringify(req.body));  
  if(typeof req.body.associateId!== 'undefined'){
	var new_associate=new Associate(req.body);
	new_associate._id= new mongoose.Types.ObjectId();
		
	new_associate.save(function(err, associate) {
	if(err){
	   res.json({ errorMessage: 'Error:Associate could not be saved. Reason: '+err.message });
	}
    else{
		console.log('Associate successfully saved.'+new_associate._id);        
		res.json(new_associate); 
    }
	});
  }
};
exports.read_a_associate = function(req, res) {
  Associate.findById({_id:req.params._id}).populate('associateSkills.skill')
  .exec(function (err, associate) {  
    if (err){
       res.json({ errorMessage: 'Error: No Associate found. Reason: '+err.message });
	}else{
		res.json(associate);
	}
  });
};
exports.update_a_associate = function(req, res) {    
  Associate.findOneAndUpdate({_id: req.params._id}, req.body, {new: true}, function(err, associate) {
    if (err){
      res.json({ errorMessage: 'Error: Updated associate failed. Reason: '+err.message });
	}else{
		res.json(associate);
	}
  });
};
exports.delete_a_associate = function(req, res) { 
  Associate.remove({_id:req.params._id}, function(err, associate) {
    if (err){
      res.json({ errorMessage: 'Error: Delete associate failed. Reason: '+err.message });
    }else{
		res.json({ message: 'Associate successfully deleted' });
	}
  });
};


