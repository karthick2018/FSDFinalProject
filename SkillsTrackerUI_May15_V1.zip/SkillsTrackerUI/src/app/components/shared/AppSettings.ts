export class AppSettings {    
    //public static API_ENDPOINT='http://user1-PC:3002/';
	public static API_ENDPOINT='http://localhost:3002/';
 }
