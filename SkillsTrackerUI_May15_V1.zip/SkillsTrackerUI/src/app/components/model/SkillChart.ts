export  class SkillChart {
     label:string[];
     values:number[];
}