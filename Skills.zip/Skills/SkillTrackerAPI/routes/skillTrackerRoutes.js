'use strict';
module.exports = function(app) {
	
  var skillsTrackerController = require('../controllers/skillsTrackerController');

  app.get("/", function(req, res) {
	res.status(200).send("Welcome to our restful API");
  }); 	
  
  app.route('/skills')
    .get(skillsTrackerController.list_all_skills)
    .post(skillsTrackerController.create_skills);
	
  app.route('/skills/:_id')
    .get(skillsTrackerController.read_a_skills)
    .put(skillsTrackerController.update_a_skills)
	.delete(skillsTrackerController.delete_a_skills);
  
  app.route('/associates')
    .get(skillsTrackerController.list_all_associates)	
    .post(skillsTrackerController.create_associate);
	
  app.route('/associates/:_id')
    .get(skillsTrackerController.read_a_associate)
    .put(skillsTrackerController.update_a_associate)
	.delete(skillsTrackerController.delete_a_associate);
	
};