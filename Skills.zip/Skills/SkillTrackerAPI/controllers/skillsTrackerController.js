'use strict';
var mongoose = require('mongoose'),

skillsModels = require("../models/SkillsTrackerSchema.js");
var Skills = skillsModels.Skills;
var Associate = skillsModels.Associate;
var AssociateSkills = skillsModels.AssociateSkills;
var Book = skillsModels.Book;
var Author = skillsModels.Author;


exports.list_all_skills = function(req, res) {
  Skills.find({}, function(err, skills) {
    if (err)
      res.send(err);
    res.json(skills);
  });
};

exports.create_skills = function(req, res) {  
  var new_skills  = new Skills(req.body);  
  new_skills.save(function(err, skills) {
    if (err)
      res.send(err);
    res.json(skills);
  });	
};

exports.read_a_skills = function(req, res) {
  Skills.findById(req.params._id, function(err, skills) {
    if (err)
      res.send(err);
    res.json(skills);
  });
};

exports.update_a_skills = function(req, res) {    
  Skills.findOneAndUpdate({_id: req.params._id}, req.body, {new: true}, function(err, skills) {
    if (err)
      res.send(err);
    res.json(skills);
  });
};

exports.delete_a_skills = function(req, res) {  
  console.log("delete_a_skills.....>>>>");
  skills.remove({_id:req.params._id}, function(err, skills) {
    if (err)
      res.send(err);
    res.json({ message: 'skills successfully deleted' });
  });
};

//Associate
exports.list_all_associates = function(req, res) {
  Associate.find({}, function(err, associate) {
    if (err)
      res.send(err);
    res.json(associate);
  });
};

exports.create_associate = function(req, res) { 
 
  console.log("req.body:"+req.body);
  
   var jamieAuthor = new Author({
    _id: new mongoose.Types.ObjectId(),
    name: {
        firstName: 'Jamie',
        lastName: 'Munro'
    },
    biography: 'Jamie is the author of ASP.NET MVC 5 with Bootstrap and Knockout.js.',
    twitter: 'https://twitter.com/endyourif',
    facebook: 'https://www.facebook.com/End-Your-If-194251957252562/'
  });
 
  jamieAuthor.save(function(err) {
    if (err) throw err;
     
    console.log('Author successfully saved.');
     
    var mvcBook = new Book( {
            _id: new mongoose.Types.ObjectId(),
            title: 'ASP.NET MVC 5 with Bootstrap and Knockout.js',
            author: jamieAuthor._id,
            ratings:[{
                summary: 'Great read'
            }]
    });
     
    mvcBook.save(function(err) {
        if (err) throw err;
     
        console.log('Book successfully saved.');
    });
     
    var knockoutBook = new Book( {
            _id: new mongoose.Types.ObjectId(),
            title: 'Knockout.js: Building Dynamic Client-Side Web Applications',
            author: jamieAuthor._id
    });
     
    knockoutBook.save(function(err) {
        if (err) throw err;
     
        console.log('Book successfully saved.');
    });
});
	console.log(req.body);
	var new_associate  = new Associate();
	if(typeof req.body.associateId!== 'undefined')
		new_associate.associateId=req.body.associateId;
	if(typeof req.body.associateName!== 'undefined')
		new_associate.associateName=req.body.associateName;
	if(typeof req.body.emailAddress!== 'undefined')
		new_associate.emailAddress=req.body.emailAddress;
	if(typeof req.body.mobileNumber!== 'undefined')
		new_associate.mobileNumber=req.body.mobileNumber;
	if(typeof req.body.strength!== 'undefined')
		new_associate.strength=req.body.strength;
	if(typeof req.body.weakness!== 'undefined')
		new_associate.weakness=req.body.weakness;
	if(typeof req.body.remarks!== 'undefined')
		new_associate.remarks=req.body.remarks;
	if(typeof req.body.associateStatus!== 'undefined')
		new_associate.associateStatus=req.body.associateStatus;
	if(typeof req.body.associateLevel!== 'undefined')
		new_associate.associateLevel=req.body.associateLevel;
	//new_associate.picture=req.body.picture;
	if(typeof req.body.associateId!== 'undefined'){
	  new_associate.save(function(err, associate) {
		if (err)
				res.send(err);
			res.json(associate);
	}
  });

/*
  var new_associate  = new Associate(req.body);  
  new_associate.save(function(err, associate) {
    if (err)
      res.send(err);
    res.json(associate);
  });*/	
};

exports.read_a_associate = function(req, res) {
  Associate.findById(req.params._id, function(err, associate) {
    if (err)
      res.send(err);
    res.json(associate);
  });
};

exports.update_a_associate = function(req, res) {    
  Associate.findOneAndUpdate({_id: req.params._id}, req.body, {new: true}, function(err, associate) {
    if (err)
      res.send(err);
    res.json(associate);
  });
};

exports.delete_a_associate = function(req, res) { 
  associate.remove({_id:req.params._id}, function(err, associate) {
    if (err)
      res.send(err);
    res.json({ message: 'Associate successfully deleted' });
  });
};
