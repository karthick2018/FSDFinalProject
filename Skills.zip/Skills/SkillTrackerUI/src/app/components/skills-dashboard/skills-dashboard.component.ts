import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {AssociateService} from '../service/associate.service';
import {Associate} from '../model/Associate';

@Component({
  selector: 'app-skills-dashboard',
  templateUrl: './skills-dashboard.component.html',
  //providers: [AssociateService],  
  styleUrls: ['./skills-dashboard.component.css']
})
export class SkillsDashboardComponent implements OnInit {

    constructor(private associateService:AssociateService,private router: Router) { }

    ngOnInit() {
		this.loadAllAssociates();
    }
    associateArray:Associate[];
	associate:Associate;
	
	loadAllAssociates(): void {
	   this.associateService.getAllAssociates()
      .subscribe(associateArray => this.associateArray = associateArray);
	}
	
	addNewAssociate() {
		this.router.navigate(['/AddAssociate']);
	}
	viewAssociate(associate:Associate) {
		console.log("View Associate:"+associate._id);	  
		this.router.navigate(['/EditAssociate'+associate._id]);    
	}
	editAssociate(associate:Associate) {
		console.log("Editing Associate:"+associate._id);	  
		this.router.navigate(['/EditAssociate'+associate._id]);
	}
	deleteAssociate(associate:Associate): void {
		console.log("Deleting Associate:"+associate._id);	  
		this.associateArray = this.associateArray.filter(h => h !== associate);
		this.associateService.deleteAssociate(associate).subscribe();
    }	
}
