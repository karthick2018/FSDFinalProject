import {Component, OnInit, ViewChild} from '@angular/core';
import {Router, ActivatedRoute, ParamMap} from '@angular/router';
import {Associate} from '../model/Associate';
import {AssociateSkills} from '../model/AssociateSkills';
import {AssociateService} from '../service/associate.service';
import {Skills} from '../model/Skills';
import {RatingModule} from 'ngx-bootstrap/rating';

export interface Config {
  heroesUrl: string;
  textfile: string;
}

@Component({
  selector: 'app-add-edit-associate',
  templateUrl: './add-edit-associate.component.html',  
  //providers: [AssociateService],  
  styleUrls: ['./add-edit-associate.component.css']
  
})
export class AddEditAssociateComponent implements OnInit {
  
  pageTitle:string;
  associateId:string;
  associate=new Associate();
  associateSkills=new AssociateSkills();
  isEditAssociate:boolean;
  errorMsg:string;
  skillsArray:Skills[];
  localUrl: any[];
  starsCount1: number;
  starsCount2: number;
  starsCount3: number;
  isReadonly:boolean;
  skills:Skills;
  config:Config;
  indexArr:number = 0;
  associateSkillsArray:AssociateSkills[];
  @ViewChild('fileInput') fileInput;
  
  constructor(private associateService:AssociateService, private router:Router,private route:ActivatedRoute) {
	this.route.params.subscribe( params => console.log(params));		
  }
  
  ngOnInit() {
	    this.isEditAssociate=false;
		this.pageTitle="Add";
		this.associateId = this.route.snapshot.paramMap.get('id');
		
		this.loadSkills();
		this.populateSkills();
		
		//console.log("skills."+this.skillsArray+"this.skillsArray.length"+this.skillsArray.length);
		
		if(this.associateId!=null){
			this.pageTitle="Edit";
			this.isEditAssociate=true;			
			this.getAssociateDetails(this.associateId);
		}		
	}	
	loadSkills():void{
	  this.associateService.getAllSkills().subscribe((s:Skills[]) => this.skillsArray=s);	  
	}
	
	lloadSkills():void{
	  this.skillsArray= this.associateService.getAllSkills().subscribe((s:Skills[]) => this.skillsArray = s;
		 console.log("skills"+this.skillsArray);
	  );
	  console.log("skills----->"+this.skillsArray);
	}
	
	populateSkills():void{		
		/*for(let i=0; i<this.skillsArray.length; i++){
			console.log(this.skillsArray[i].skillName); //use i instead of 0
		}*/
	}
	upload() {
		let fileBrowser = this.fileInput.nativeElement;
		if (fileBrowser.files && fileBrowser.files[0]) {
		  const formData = new FormData();
		  formData.append("image", fileBrowser.files[0]);
		  /*this.projectService.upload(formData, this.project.id).subscribe(res => {
			// do stuff w/my uploaded file
		  });*/
		}
	}
    
	showPreviewImage(event: any) {
        if (event.target.files && event.target.files[0]) {
            var reader = new FileReader();
            reader.onload = (event: any) => {
                this.localUrl = event.target.result;
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    }	
	
	/** GET getAssociateDetails by id. Will 404 if id not found */
	getAssociateDetails(id: string){	
	 this.associateService.getAssociateDetails(id)
      .subscribe(associate => this.associate = associate);
	}  
    //call service to save Associate
    addEditAssociate(): void {	
		console.log("this.isEditAssociate:"+this.isEditAssociate);
				
	    if(this.skillsArray!=null){			
			assocSkill:AssociateSkills;
			skill:Skills;			
			this.indexArr= 0;
			this.associateSkillsArray=new Array(this.skillsArray.length);
			for (let sk of this.skillsArray) {				
				this.assocSkill=new AssociateSkills();
				this.skill=new Skills();
				this.skill._id=sk._id;
				this.skill.skillName=sk.skillName;				
				this.associateSkills.skills=this.skill;
				this.associateSkills.skillRating=sk.skillRating;				
				this.associateSkillsArray[this.indexArr]=this.associateSkills;
				this.indexArr=this.indexArr+1;		
			}
			if(this.associate!=null)
				this.associate.associateSkills=this.associateSkillsArray;
			console.log("associateSkillsArray:"+this.associateSkillsArray);			
		}
		if(!this.isEditAssociate){			
			if(this.associate.associateId==null || this.associate.associateId==null){
				this.errorMsg="Associate Id is mandatory";
				return;
			}	 			
			this.errorMsg=null;
			console.log('Associate data'+JSON.stringify(this.associate));			
			this.associateService.saveAssociate(this.associate)
				  .subscribe(associate => {				   
					  console.log("Associate Saved");
					  this.router.navigate(['/skillsDashboard']);				  
			 });
	    }else{
		  this.associateService.updateAssociate(this.associate)
			  .subscribe(associate => {				   
				  console.log("Associate Updated");
				  this.router.navigate(['/skillsDashboard']);				  
		 });		  
		 this.router.navigate(['/skillsDashboard']);
	  }
    }
	
	cancelAddEdit() {		
		this.router.navigate(['/skillsDashboard']);
    }
	resetAddEdit() {
		this.associate=new Associate();
    }	
}

