export class Skills {	
	constructor() {}
	_id:string;    
	skillName:string;
	skillRating:number;
}