import {Skills} from './Skills';

export class AssociateSkills {	
	constructor() {}
	_id:string;    
	associateId:string;
	skills:Skills;
	skillRating:number;	
}